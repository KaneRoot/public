#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "simul.h"

/*
 * Q1.2 : Creation d'un nouveau processus
 */

struct pcb *pcb_create (int pid, int start, int duration, int prio)
{
    /* A ecrire */
}

/*
 * Suppression d'un processus
 */

void pcb_destroy (struct pcb *pcb)
{
    free (pcb) ;
}
