<?php
	$conn = oci_connect("pittoli", "1712juph", "localhost/ROSA");
	if(! $conn) 
	{
		echo "Erreur de connexion";
		exit;
	}
?>
